
export const dictionaty = async (startChar) => {
  const API_KEY="E0CE150205F2EF760487E18E1B797CDB";
  const base = "https://opendict.korean.go.kr/api/search";
  const params = new URLSearchParams({
    key: API_KEY,
    q: startChar,
    req_type: "json",
    part: "word",
    advanced: "y",
    sort: "popular",
    num: "10",
    pos: "1",        // 명사
    method: "start", // 시작 글자
    target: "1",      // 표제어
    type1:"word"
  });

  const originURL = `${base}?${params.toString()}`;
  console.log( originURL );
  const proxyURL = `https://corsproxy.io/?${encodeURIComponent(originURL)}`;
  try{
    const res = await fetch(proxyURL);
    const data = await res.json();
    const word = data.channel.item[0].word;
    return word;
  } catch(err){
    console.log( "API오류",err);
    return null;
  }
};