import { useState } from "react";
import {dictionaty} from "../api/dictionaty.js";

const GameScreen = ({startWord}) => {
  const [words,setWords] = useState([startWord]);
  const addWord = (text)=>{
    setWords((prev)=>{return [...prev,text]});
  }
  const handleSubmit = ()=>{
    const word = dictionaty(startWord[startWord.length-1]);
    if( word ){
      addWord(word);
    }
  }
  return (
    <div className="game-screen">
      <h2>Hello, I'AM 말잇쮸</h2>
      <ul className="word-list">
        {
          words.map((item,idx)=>{
            return <li key={idx}>{item}</li>;
          })
        }
      </ul>      
      <form className="game-form" onSubmit={handleSubmit}>
        <input />
        <button type="submit">▶</button>
      </form>    
    </div>
  );
};

export default GameScreen;